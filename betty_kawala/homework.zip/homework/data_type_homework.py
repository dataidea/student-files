# How to find the data_type of an object
# To check data_type of an object we can use print(type()) 
#example
name ='Betty'
print(type(name))

height = 4.5
print(type(height))