# How to write a code that picks the last letter of a text
# Write a code that picks the last letter in the text 'He loves to code in Python'
text ='He loves to code in python'
print(text[25]) 

# How to check if some text is in a string
# Find if the word code is in the text 'I love to code in python'

text = 'I love to code in python'
is_code = 'code'in text
print(is_code)