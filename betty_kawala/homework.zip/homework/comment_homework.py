# How to write a comment that covers more than one line
# We can write a comment that covers more than one line by using the 
# character
# We enclose the multiple line comment in triple double quotes(""") or triple single quotes (''')